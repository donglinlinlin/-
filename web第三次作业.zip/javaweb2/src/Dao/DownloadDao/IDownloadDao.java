package Dao.DownloadDao;

public interface IDownloadDao extends DownloadDao {
}
