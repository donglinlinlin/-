package Dao.UserDao;

import Dao.UserDao.UserDao;
import Vo.User;

public interface IUserDao extends UserDao<User,String> {
    //可以新增DAO操作功能
}
